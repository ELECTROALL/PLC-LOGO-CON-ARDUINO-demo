#include "ladder.h"
//#device PIC16F628

/*
void setPortDigitalIO() {
   setup_adc_ports(ALL_DIGITAL);
}
*/
