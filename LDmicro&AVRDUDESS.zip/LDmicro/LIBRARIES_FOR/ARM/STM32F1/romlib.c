
void EEPROM_write(unsigned char addr, unsigned char data)
{
    #warning EEPROM not supported by this target, but you can provide an implementation of write EEPROM data for an external EEPROM chip!
}

unsigned char EEPROM_read(int addr)
{
    #warning EEPROM not supported by this target, but you can provide an implementation of reading EEPROM data for an external EPPROM chip!
}
