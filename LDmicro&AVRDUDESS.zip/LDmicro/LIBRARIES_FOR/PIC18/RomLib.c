#include <htc.h>

#include "ladder.h"
#include "RomLib.h"

unsigned char EEPROM_error()
{
    return WRERR;
}

unsigned char EEPROM_busy()
{
    //WRERR = 0;
    return EECON1bits.WR | EECON1bits.RD;
    /*
    if(WR)
        return  1;
    if(RD)
        return  1;
    return  0;
    */
}

void Set_EEPROM_Address_Register(uint16_t address)
{
    #ifdef EEPGD
    EEPGD = 0;
    #endif
    #ifdef CFGS
    CFGS = 0;
    #endif
    EEADR = address & 0xFF;
}

unsigned char EEPROM_read(uint16_t address)
{
    while(EEPROM_busy())
        ; //
    Set_EEPROM_Address_Register(address);
    EECON1bits.RD = 1;
    return EEDATA;
}

void EEPROM_write(uint16_t address, unsigned char data)
{
    while(EEPROM_busy())
        ;
    Set_EEPROM_Address_Register(address);
    EEDATA = data;

    char cINTCON = INTCON;
    GIE = 0;
    while(GIE)
        ; // disable interrupts

    EECON1bits.WREN = 1;
    EECON2 = 0x55;
    EECON2 = 0xAA;
    EECON1bits.WR = 1;
    EECON1bits.WREN = 0;

    INTCON = cINTCON; // restore
}
