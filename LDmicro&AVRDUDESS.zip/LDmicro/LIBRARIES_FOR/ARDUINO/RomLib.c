#include "ladder.h"
#include "RomLib.h" // Fichier header librairie EEPROM

#include <EEPROM.h>

#ifndef USE_MACRO
  void EEPROM_write(int addr, unsigned char data) {
    EEPROM.write(addr, data);
  }
  unsigned char EEPROM_read(int addr) {
    return EEPROM.read(addr);
  }
#endif
void EEPROM_fill(int addr1, int addr2, unsigned char data) {
    for (int i = max(0,addr1) ; i < min(addr2+1, EEPROM.length()) ; i++)
        EEPROM.write(i, data);
}
