
void EEPROM_write(unsigned char addr, unsigned char data)
{
    #warning You must provide an implementation of write EEPROM data for you target MCU or for an external EEPROM chip!
}

unsigned char EEPROM_read(int addr)
{
    #warning You must provide an implementation of reading EEPROM data for you target MCU or for an external EPPROM chip!
}
